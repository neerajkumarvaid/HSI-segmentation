# -*- coding: utf-8 -*-
"""
Created on Sun Jun 10 14:14:54 2018

@author: Neeraj
"""

import os
os.chdir('/Users/apple/Documents/CodesResearch/HSI_medical/Phani_final')
from loaddata import loaddata, get_train_data
from ssnmf_func import ssnmf
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from PIL import Image as pimg
import matplotlib
import os
from sklearn.cluster import DBSCAN
from spectral import *
from sklearn import svm
import time
from sklearn.semi_supervised import label_propagation
from load_ssnmf_feat import ssnmf_feat
import scipy.io as sio

data = sio.loadmat('./spectra_of_labeled_pixels/tsne_raw_pxels.mat')

X = data['X'].transpose()
labels = data['labels']
labels  = np.int64(labels.reshape((6000,)))
rank = 10
L_param = 0.01
l = 1

feat_mat,label_mat,data_recon_err,label_recon_err,eval_s = ssnmf(X,labels,rank,l,relax_label = True,L_param=L_param)

ssnmf_features = feat_mat
ssnmf_labels = label_mat

sio.savemat('./spectra_of_labeled_pixels/ssnmf_features.mat',{'X':ssnmf_features,'labels':ssnmf_labels})
