from loaddata import loaddata, get_train_data
from ssnmf_func import ssnmf
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from PIL import Image as pimg
import matplotlib
import os
from sklearn.cluster import DBSCAN
from spectral import *
from sklearn import svm
import time
from sklearn.semi_supervised import label_propagation
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from load_ssnmf_feat import ssnmf_feat

lambda_vals = [0.1, 0.5, 1, 2, 3, 5, 9]
fullfile = os.path.dirname(os.path.abspath(__file__))+ '/all_images_feat_ext_new/' 
f = fullfile + ('all_img1010_feat_ssnmf_')
fsc = []
op_f = fullfile + "fsc_0.txt"
for lnum,l in enumerate(lambda_vals):
	data = np.load(f + str(lnum) + ".npz")
	print "Predicted labels:",np.shape(data['label_mat'])
	print "Input labels:",np.shape(data['input_labels'])
	print "Total lables:",np.shape(data['tot_labels'])

	pred_labels = np.argmax(data['label_mat'], axis = 0) + np.ones(np.shape(data['label_mat'])[1], dtype=int)
	act_labels = data['input_labels']

	prec, rec, f_sc = [], [], []
	for i in range(1,4):
		same_class = (act_labels == i)
		predicted_class = (pred_labels == i)		
		diff_class = np.ones(np.shape(act_labels)[0]) - same_class
		tp = np.dot(1*same_class, predicted_class)
		fp = np.dot(1*diff_class, predicted_class)
		fn = np.dot(1*same_class, np.ones(np.shape(act_labels)[0])-predicted_class)
		pr = float(tp)/(tp+fp)
		re = float(tp)/(tp+fn)
		print sum(same_class), sum(predicted_class)
		print tp,fp,fn
		print pr, re
		# raw_input()
		prec.append(pr)
		rec.append(re)
		f_sc.append( 2 * pr * re / (pr + re) )
	f_sc_avg = sum(f_sc)/len(f_sc)
	fsc.append(f_sc_avg)
	print "Lambda:", l, f_sc_avg
	print prec, "\n", rec, "\n", f_sc, "\n"
	print "A--------------------------"
	with open(op_f, "a+") as op_file:
		op_file.write(str(l) + "\t" + str(f_sc_avg) + "\n")

	# print classification_report(data['input_labels'], pred_labels)
	# c_matrix = confusion_matrix(data['input_labels'], pred_labels)
	# print c_matrix
	# c_matrix = c_matrix[np.ix_([x for x in range(1,5)], [x for x in range(1,5)])]
	# row_sum, col_sum = np.sum(c_matrix, axis=1), np.sum(c_matrix, axis=0)
	# print c_matrix
	# print col_sum
	# # print row_sum, col_sum
	# for i in range(np.shape(c_matrix)[0]):
	# 	prec.append(c_matrix[i][i]/float(row_sum[i]))
	# 	rec.append(c_matrix[i][i]/float(col_sum[i]))
	# raw_input()
# plt.figure()
# plt.plot(lambda_vals, fsc)
# plt.xlabel("Lambda")
# plt.ylabel("FScore")
# plt.savefig(fullfile + "fsc_0.png")
with open(op_f, "a+") as op_file:
	op_file.write("A----------------------------------------\n")
	op_file.write("A----------------------------------------\n")