# -*- coding: utf-8 -*-
"""
Created on Wed Sep 14 23:51:04 2016

@author: apple
"""

from spectral import *
import spectral.io.envi as envi
import numpy
from PIL import Image as pimg
from skimage.color import label2rgb

i = 10

str1=("Normal%d.hdr"%(i))
str2=("Normal%d"%(i))            
img=envi.open(str1,str2).load()

img = numpy.asarray(img,dtype= numpy.float32)


color_val =spy_colors
color_val[0] = color_val[1]
color_val[1] = color_val[2]
color_val[2] = color_val[3]
color_val[3] = [0,0,0]
colors = [(1, 0, 0), (0, 1, 0), (1, 1, 0)]

img_te = []

for k in range(img.shape[0]):
    for j in range(img.shape[1]):
        img_te.append(img[k,j,:])
        
        
img_te = numpy.asarray(img_te,dtype=numpy.float32)

print img_te.shape
temp1 = numpy.min(img_te,axis=1)
temp2 = numpy.max(img_te,axis=1)
temp1 = numpy.fabs(temp1)
temp3 = (temp2 - temp1) < 0.07

#newImg1 = pimg.fromarray(numpy.uint8(255*(temp3.reshape([img.shape[0] ,img.shape[1]]))))
#str4 = fullfile + ('bg_vs_fg%d.png'%(i))
#newImg1.save('/Users/apple/Desktop/Normal1.bmp',"BMP")



gt_te = img_te[:,226:]
gt = numpy.zeros(gt_te.shape[0])
gt1 = gt_te[:,0]*gt_te[:,1]+gt_te[:,1]*gt_te[:,2]+gt_te[:,2]*gt_te[:,0]
gt1 = gt1 == 0
gt = gt_te[:,0]* gt1 + 2*gt_te[:,1]* gt1 + 3* gt_te[:,2]* gt1
#gt = numpy.asarray(gt,dtype=int)
#gt = gt + 4*temp3

imgt = numpy.reshape(gt,(img.shape[0],img.shape[1]))
imgt = label2rgb(imgt,bg_label=4,bg_color=(0,0,0), colors = colors)
newImg1 = pimg.fromarray(numpy.uint8(255*imgt))
svname ='/Users/apple/Desktop/' + str2 + '.bmp'
newImg1.save(svname,"BMP")
#save_rgb('/Users/apple/Desktop/Normal1.jpg', img, colors=color_val)