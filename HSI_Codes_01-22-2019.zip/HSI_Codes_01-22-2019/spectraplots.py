# -*- coding: utf-8 -*-
"""
Created on Thu Jun  7 21:03:10 2018

@author: Neeraj
"""
import os
os.chdir('/Users/apple/Documents/CodesResearch/HSI_medical/Phani_final')
from loaddata import loaddata, get_train_data
from ssnmf_func import ssnmf
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from PIL import Image as pimg
import matplotlib
import os
from sklearn.cluster import DBSCAN
from spectral import *
from sklearn import svm
import time
from sklearn.semi_supervised import label_propagation
from load_ssnmf_feat import ssnmf_feat
import scipy.io as sio
images = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,20]
directory = './spectra_of_labeled_pixels/'
#images = [1]
for noi,i in enumerate(images):
    data_pi = loaddata(i,0.07)
    data_oi = data_pi[0]
    tot_labels = data_pi[1]
    labeled_pos = [x for x in range(tot_labels.shape[0]) if tot_labels[x] != 0 and tot_labels[x] != 4]
    spectra = data_oi[:,labeled_pos]
    labels = tot_labels[labeled_pos]
    file_name = directory + 'image_' + str(i)
    sio.savemat(file_name,{'spectra':spectra,'labels':labels})