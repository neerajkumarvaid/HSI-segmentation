from loaddata import loaddata, get_train_data
from ssnmf_func import ssnmf
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from PIL import Image as pimg
import matplotlib
import os
from spectral import *
from sklearn import svm
import time
from load_ssnmf_feat import ssnmf_feat
from scipy.cluster.hierarchy import dendrogram, linkage, fcluster, centroid, weighted

start_time = time.time()

random_state = 170
color_val =spy_colors
color_val[0] = color_val[1]
color_val[1] = color_val[2]
color_val[2] = color_val[3]
color_val[3] = [0,0,0]
bg_param = 0.07


fullfile = os.path.dirname(os.path.abspath(__file__))+ ('/all_images_feat_ext_subsampled_new/')
op_dir = fullfile + "/res_ssnmf_sshieclus/"
lambda_lij_pair = [(2,1)]
rank, lambda_lij = 10, (0.005, 1)

if(os.path.exists(op_dir) == False):
    os.makedirs(op_dir)

# for i in range(1,11):
for i in [1]:
	no_clus = 50 #KARTHIK: Modified after experiments with the combined dataset
	data = loaddata(i, bg_param)
	s0, s1 = data[2], data[3]
	ssnmf_feat_data = np.load(fullfile + "label_feat_dump_" + str(lambda_lij_pair[0][0]) + "_" + str(lambda_lij_pair[0][1]) + ".npz")
	feat_mat = np.transpose(ssnmf_feat_data['features'][:])	
	feat_mat = feat_mat[:s0*s1, :]
	print "feat mat shape",np.shape(feat_mat)
	rank = feat_mat.shape[1]
	labels = (np.load(os.path.dirname(os.path.abspath(__file__)) + "/direct_ssnmf_recon/Normal_1/" + "tot_labels_lp_recon_" + str(10) + "_" + str(lambda_lij[0]) + "_" + str(lambda_lij[1]) + ".npz"))['tot_pred_labels']
	clus_pred = np.array(KMeans(n_clusters=no_clus, random_state=random_state).fit_predict(feat_mat))
	for c_num in range(ncluster):
		cl_labels = labels[(clus_pred == c_num)]
		assigned_label = np.bincount(cl_labels).argmax()
		labels[(clus_pred == c_num)] = assigned_label

	y_pred = np.empty((no_clus,s0*s1))
	y_pred[0] = labels.reshape((s0*s1,))
	for j in range(no_clus):
		y_pred[j] = y_pred[0]
	
	pos =[]

	for j in range(no_clus):
		temp_pos = [[x for x in range(s0*s1) if y_pred[0,x] == j]]
		pos += temp_pos
	redu_clus = np.empty((no_clus,rank))
	for j in range(no_clus):
		print np.shape(pos[j]), np.shape(feat_mat)
		redu_clus[j] = np.mean(feat_mat[pos[j]],axis =0)
	Z = linkage(redu_clus,'ward')
	Z = np.asarray(Z,dtype = 'int32')

	for k in range(Z.shape[0]):
		tempr = min(Z[k,0], Z[k,1])
		temps = no_clus+k
		Z[k,2] = tempr
		for l in range(k+1,Z.shape[0]):
		        if Z[l,0] == temps:
		                Z[l,0] = tempr
		        if Z[l,1] == temps:
		                Z[l,1] = tempr
	for k in range(Z.shape[0]):
		mi_val = Z[k,2]
		clu_1 = Z[k,0]
		clu_2 = Z[k,1]
		pos[mi_val] = pos[clu_1]+pos[clu_2]
		y_pred[k+1,pos[mi_val]] = mi_val
		for j in range(k+2,no_clus):
		        y_pred[j] = y_pred[k+1]
	for k in range(no_clus):       
		labels = y_pred[k].reshape(s0,s1) 		
		f2 = (op_dir + 'hie_over_km_%d_%d.jpg'%(i,k))
		save_rgb(f2, labels,colors=color_val )
print("--- %s seconds ---" % (time.time() - start_time))