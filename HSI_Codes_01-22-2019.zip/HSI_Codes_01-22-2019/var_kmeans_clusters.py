from loaddata import loaddata, get_train_data
from ssnmf_func import ssnmf
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from PIL import Image as pimg
import matplotlib
import os
from spectral import *
from sklearn import svm
import time
from load_ssnmf_feat import ssnmf_feat


def loadfeat(curr_nmf):    
    fullfile = os.path.dirname(os.path.abspath(__file__))+ ('/all_images_feat_ext_subsampled_new/') 
    f = fullfile + curr_nmf
    feat = np.load(f)
    return feat['features'],feat['label_mat'],feat['tot_labels'],feat['test_pos'],\
           feat['data_recon_err'],feat['label_recon_err']

start_time = time.time()

label_features = [(1, 1), (2, 1), (3, 1)]
ncluster_vals = [30, 35, 40, 45, 50, 60, 70, 80, 90, 100]

for i in label_features:
	feat_mat,label_mat,_,_,_,_=loadfeat('label_feat_dump_' + str(lnum) + '_' + str(inum) + '.npz')
	for ncluster in ncluster_vals:
		random_state = 170
		y_pred = KMeans(n_clusters=ncluster, random_state=random_state).fit_predict(feat_mat)
		print y_pred.shape		


print("--- %s seconds ---" % (time.time() - start_time))